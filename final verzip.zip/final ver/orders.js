const currentUser =
JSON.parse(
localStorage.getItem(
"currentUser"
)
);

if(!currentUser){

window.location.href =
"index.html";

} 
let inventory =
JSON.parse(
localStorage.getItem("inventory")
) || [];

let orders =
JSON.parse(
localStorage.getItem("orders")
) || [];

let customers =
JSON.parse(
localStorage.getItem("customers")
) || [];

const categorySelect =
document.getElementById(
"eggCategory"
);

inventory.forEach(item=>{

categorySelect.innerHTML +=
`<option value="${item.id}">
${item.category}
</option>`;

});

function calculateTotal(){

const categoryId =
parseInt(
document.getElementById(
"eggCategory"
).value
);

const trays =
parseInt(
document.getElementById(
"trayCount"
).value
) || 0;

const item =
inventory.find(
i => i.id === categoryId
);

if(!item) return;

document.getElementById(
"pricePerTray"
).value =
"₱" + item.pricePerTray;

document.getElementById(
"totalAmount"
).value =
"₱" +
(item.pricePerTray * trays);

}

function createOrder(){

const customer =
document.getElementById(
"customerName"
).value;

const contact =
document.getElementById(
"customerContact"
).value;

const address =
document.getElementById(
"customerAddress"
).value;

const categoryId =
parseInt(
document.getElementById(
"eggCategory"
).value
);

const trays =
parseInt(
document.getElementById(
"trayCount"
).value
);

if(
!customer ||
!contact ||
!address ||
!trays
){

alert(
"Complete all fields."
);

return;
}

const item =
inventory.find(
i => i.id === categoryId
);

if(item.trays < trays){

alert(
"Not enough trays available."
);

return;
}

const total =
item.pricePerTray * trays;

item.trays -= trays;

const order = {

id: Date.now(),

customer: customer,

contact: contact,

address: address,

category: item.category,

trays: trays,

pricePerTray:
item.pricePerTray,

total: total,

status: "Pending",

date:
new Date()
.toLocaleString()

};

orders.push(order);

customers.push({

name: customer,

contact: contact,

address: address

});

localStorage.setItem(
"orders",
JSON.stringify(orders)
);

localStorage.setItem(
"customers",
JSON.stringify(customers)
);

localStorage.setItem(
"inventory",
JSON.stringify(inventory)
);

addTransaction(
"Order Created"
);

renderOrders();

clearForm();

}

function clearForm(){

document.getElementById(
"customerName"
).value="";

document.getElementById(
"customerContact"
).value="";

document.getElementById(
"customerAddress"
).value="";

document.getElementById(
"trayCount"
).value="";

document.getElementById(
"pricePerTray"
).value="";

document.getElementById(
"totalAmount"
).value="";

}

function updateStatus(id){

const order =
orders.find(
o => o.id === id
);

const newStatus =
prompt(
"Enter Status:\nPending\nProcessing\nDelivered\nCancelled",
order.status
);

if(newStatus){

order.status =
newStatus;

localStorage.setItem(
"orders",
JSON.stringify(orders)
);

addTransaction(
"Order Status Updated"
);

renderOrders();

}

}

function renderOrders(){

const body =
document.getElementById(
"ordersBody"
);

body.innerHTML="";

orders.forEach(order=>{

body.innerHTML += `

<tr>

<td>${order.customer}</td>

<td>${order.category}</td>

<td>${order.trays}</td>

<td>₱${order.total}</td>

<td>

<span class="${order.status.toLowerCase()}">

${order.status}

</span>

</td>

<td>

<button
onclick="updateStatus(${order.id})">

Update

</button>

</td>

</tr>

`;

});

}

function addTransaction(action){

let transactions =
JSON.parse(
localStorage.getItem(
"transactions"
)
) || [];

transactions.push({

action: action,

date:
new Date()
.toLocaleString()

});

localStorage.setItem(
"transactions",
JSON.stringify(transactions)
);

}

renderOrders();